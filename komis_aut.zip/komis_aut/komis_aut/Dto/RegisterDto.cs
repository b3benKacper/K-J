﻿namespace komis_aut.Dto
{
    public class RegisterDto
    {  
        public string Email { get; set; }
        public string Password { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
    }
}
